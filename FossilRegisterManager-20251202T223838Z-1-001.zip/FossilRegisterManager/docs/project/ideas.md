# Ideas
## Main Functionalities
+ Create a file related an specific animal
+ IA that can be used to solve questions using the info of the files
+ Hyperlinks between files and links to external webs
+ Add images to the register
+ Get data from some specified websites and compare it
+ Search registers from the database filtering by some atributes
+ Export/Import records