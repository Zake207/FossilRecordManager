# Pendientes
 + Establecer herramientas de desarrollo universales entre maquina portatil y la de casa
 + Comprobar la documentación inicial con el chatbot del proyecto
 + Revisar que toda la documentación del proyecto este completa hasta antes de Frontend
 + Comenzar a plantear una ruta de acción de la FASE 3: SUPABASE & FASTAPI