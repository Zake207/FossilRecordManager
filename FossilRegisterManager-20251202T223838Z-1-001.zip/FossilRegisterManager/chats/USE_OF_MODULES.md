# DEVELOPMENT
[Project](https://chatgpt.com/g/g-p-69145dbc52c8819183976531b480c7ce-fossil-register-manager/project)
## Tools
[Poetry](https://chatgpt.com/share/69287b28-c5b4-800e-8a7a-3d6677024a08)
## Backend
[Configuración de la base de datos](https://chatgpt.com/share/692de7df-a120-800e-b8f2-c773b4b97a3f)
## Frontend