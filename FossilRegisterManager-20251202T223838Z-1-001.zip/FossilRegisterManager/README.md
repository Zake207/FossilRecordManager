# Fossil Register Manager
## Usage
## Ideas
+ Página web
+ Crear entradas de especies de dinosaurios
+ Crear notas ascosiadas al mismo
+ Hacer web Scrapping de ciertas páginas verificadas como wikipedia y demas
+ Alojarlo todo en una base de datos (explorar Supabase)
+ Incluir fotos en los registros
+ Comparar la info de los scraps
+ Integrar una ia a la que hacer preguntas basandose en los registros existentes que pregunte si quieres realizar busquedas en las páginas web establecidas.
+ CONTRASEÑA DE LA BASE DE DATOS: FossilPedia-207
