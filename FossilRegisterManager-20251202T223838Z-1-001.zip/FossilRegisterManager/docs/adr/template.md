# ADR XXX: Title

**Date:** DD-MM-YYYY  
**State:** (Accepted / Rejected / Pending)

## Context
Context where the decition was made

## Election
The decition itself

## Considered Alternatives
- Alternatives 1
- Alternatives 2


## Consequences
### Good
- ...
### Bad
- ...

## References
- [Documentation](https://google.com)